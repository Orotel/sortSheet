switch(opcao) {
  case "incorporadora":
    incorporadora.push(contato);
    break;
  case "construtora":
    construtora.push(contato);
    break;
  case "fundo":
    fundo.push(contato);
    break;
  case "investidor":
    investidor.push(contato);
    break;
  case "banco":
    banco.push(contato);
    break;
  case "industria":
    industria.push(contato);
    break;
  case "empresa":
    empresa.push(contato);
    break;
  default:
    console.log("Opção inválida");
}

incorporadora = []
construtora = []
fundo = []
investidor = []
banco = []
industria = []
empresa = [] 