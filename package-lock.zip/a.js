function storeMatches(keywords){
  switch(this.keywords) {
    case "incorporadora":
      incorporadora.push(incorporadora);
      break;
    case "construtora":
      construtora.push(const);
      break;
    case "fundo":
      fundo.push(contato);
      break;
    case "investidor":
      investidor.push(contato);
      break;
    case "banco":
      banco.push(contato);
      break;
    case "industria":
      industria.push(contato);
      break;
    case "empresa":
      empresa.push(contato);
      break;
    default:
      console.log("Opção inválida");
  }
  


 }